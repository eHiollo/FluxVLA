"""Loopback client for the timed Plan; hardware-selected A defaults, each point once."""
import json
import math
import socket
import time
from client import Client


def encode_target(stream_id,index,position_rad,final=False):
    """Axis order: physical right ee0[6], then physical left ee1[6]."""
    if type(stream_id) is not int or type(index) is not int or not 0<stream_id<2**64 or not 0<=index<2**64:
        raise ValueError('invalid stream ID or index')
    values=[float(x) for x in position_rad]
    if len(values)!=12 or not all(math.isfinite(x) for x in values):
        raise ValueError('expected exactly twelve finite absolute radians; no gripper')
    return json.dumps(dict(stream_id=stream_id,index=index,position_rad=values,
                           final=bool(final)),separators=(',',':'),allow_nan=False).encode()


class TimedJointClient:
    def __init__(self,command_client=None):
        # Reuse an existing command channel when the host already controls the
        # SDK: its WebSocket listener serves one command connection at a time.
        self.owns_commands=command_client is None
        self.commands=Client() if self.owns_commands else command_client
        self.socket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.stream_id=None;self.index=0;self.ended=False;self.last_position_deg=None

    def status(self):
        return self.commands.command('taj_status')

    def start(self,delay=.04,omega=25,jerk_deg_s3=5000,lookahead=1,velocity_ff=.8,acceleration_ff=0,velocity_bandwidth_hz=3,terminal_ff_time_s=.04,startup_ff_time_s=0):
        # Matching legacy keywords remain accepted; production tuning is locked.
        values=(delay,omega,jerk_deg_s3,lookahead,velocity_ff,acceleration_ff,velocity_bandwidth_hz,terminal_ff_time_s,startup_ff_time_s)
        fixed=(.04,25,5000,1,.8,0,3,.04,0)
        if any(not math.isfinite(v) or abs(v-f)>1e-12 for v,f in zip(values,fixed)):
            raise ValueError('timed_aj is fixed to tested A; tuning overrides are disabled')
        status=self.status()
        if status['active']:raise RuntimeError('another timed stream is active')
        robot=self.commands.state()['robot_msg']
        if (robot['op_mode'],robot['activate'],robot['status'],robot['motion'])!=('Manual','Enabled','Normal','Stopped'):
            raise RuntimeError('start requires Manual / manual_en / Normal / Stopped')
        previous_id=status['stream_id']
        self.commands.start_plan('timed_aj')
        for _ in range(250):
            status=self.status()
            if status['active'] and status['ready'] and status['stream_id']>previous_id:
                self.stream_id=status['stream_id'];self.index=0;self.ended=False;return status
            time.sleep(.02)
        raise RuntimeError('timed Plan did not start')

    def send(self,position_rad,final=False):
        if self.stream_id is None or self.ended:raise RuntimeError('start a new stream before sending')
        values=list(position_rad);body=encode_target(self.stream_id,self.index,values,final)
        self.socket.sendto(body,('127.0.0.1',10000))
        index=self.index;self.index+=1;self.ended=bool(final)
        self.last_position_deg=[float(q)*180/math.pi for q in values]
        return index

    def wait_finished(self,timeout_s=3,position_tolerance_deg=.3,speed_tolerance_deg_s=.5,stable_s=.04):
        """Wait on motor commands; never resend a target or shift a timeline."""
        if not self.ended:raise RuntimeError('mark the final point before waiting for completion')
        def flatten(value):
            if isinstance(value,list):return [x for part in value for x in flatten(part)]
            return [float(value)]
        deadline=time.monotonic()+timeout_s;previous=None;quiet_since=None
        while time.monotonic()<deadline:
            status=self.status()
            if status['stream_id']!=self.stream_id or not status['active'] or status['reason']:
                raise RuntimeError('timed stream interrupted: '+str(status))
            values=flatten(self.commands.state()['motion_msg']['motor_pos']);now=time.monotonic()
            if len(values)!=12 or not all(math.isfinite(x) for x in values):raise ValueError('invalid motor positions')
            near=max(abs(a-b) for a,b in zip(values,self.last_position_deg))<=position_tolerance_deg
            slow=previous is not None and max(abs(a-b)/(now-previous[0]) for a,b in zip(values,previous[1]))<=speed_tolerance_deg_s
            if status['final_reference_reached'] and status['consumed']==self.index and near and slow:
                if quiet_since is None:quiet_since=now
                if now-quiet_since>=stable_s:return status
            else:quiet_since=None
            previous=(now,values);time.sleep(.02)
        raise TimeoutError('timed endpoint did not settle within the completion timeout')

    def stop(self):
        status=self.status()
        if self.stream_id is None or status['stream_id']!=self.stream_id:return status
        self.commands.command('taj_stop')
        for _ in range(250):
            status=self.status()
            if not status['active'] and self.commands.state()['robot_msg']['motion']=='Stopped':self.ended=True;return status
            time.sleep(.02)
        raise RuntimeError('timed stop not confirmed')

    def close(self):
        try:self.stop()
        finally:
            self.socket.close()
            if self.owns_commands:self.commands.close()

    def __enter__(self):return self
    def __exit__(self,exc_type,*_):
        try:
            if exc_type is None and self.ended:self.wait_finished()
        finally:self.close()
