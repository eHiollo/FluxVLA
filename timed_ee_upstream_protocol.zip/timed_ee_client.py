"""Dual-EE 30 Hz single-send client, sharing timed_aj ownership and transport."""
import json
import math
import time
from timed_client import TimedJointClient


def encode_ee_target(stream_id,index,poses,final=False):
    if type(stream_id) is not int or type(index) is not int or not 0<stream_id<2**64 or not 0<=index<2**64:
        raise ValueError('invalid internal task ID or index')
    values=[[float(x) for x in pose] for pose in poses]
    if len(values)!=2 or any(len(p)!=7 for p in values):raise ValueError('expected ee0/right and ee1/left, each xyz_m plus quaternion_xyzw')
    for pose in values:
        if not all(math.isfinite(x) for x in pose):raise ValueError('non-finite EE target')
        norm=sum(x*x for x in pose[3:])
        if abs(norm-1)>.002:raise ValueError('quaternion must be unit length')
        pose[3:]=[x/math.sqrt(norm) for x in pose[3:]]
    return json.dumps(dict(stream_id=stream_id,index=index,pose_m_quat=values,frame='wobj0',tool='tool1',final=bool(final)),separators=(',',':'),allow_nan=False).encode()


class TimedEeClient(TimedJointClient):
    plan_command='timed_ee'
    status_command='tee_status'
    stop_command='tee_stop'

    def start(self):
        return super().start()

    def send(self,poses,final=False):
        if self.stream_id is None or self.ended:raise RuntimeError('start a new stream before sending')
        body=encode_ee_target(self.stream_id,self.index,poses,final)
        self.socket.sendto(body,(self.host,self.udp_port))
        index=self.index;self.index+=1;self.ended=bool(final)
        return index

    def wait_finished(self,timeout_s=5,speed_tolerance_deg_s=.5,stable_s=0):
        """Wait for capture completion and the declared EE band; command FK is not real feedback."""
        if not self.ended:raise RuntimeError('mark the final point before waiting for completion')
        deadline=time.monotonic()+timeout_s;quiet=None
        while time.monotonic()<deadline:
            status=self.status();now=time.monotonic()
            if status['stream_id']!=self.stream_id or not status['active'] or status['reason'] or status.get('control_space')!='ee':
                raise RuntimeError('EE stream interrupted: '+str(status))
            tolerance=math.radians(status['parameters']['endpoint_tolerance_deg'])
            near=max(abs(q-g) for q,g in zip(status['command_joint_rad'],status['joint_goal_rad']))<=tolerance+1e-9
            slow=max(abs(v) for v in status['command_joint_velocity_rad_s'])<=math.radians(speed_tolerance_deg_s)
            pose_near=max(status['endpoint_position_error_m'])<=status['endpoint_position_tolerance_m'] and max(status['endpoint_orientation_error_rad'])<=status['endpoint_orientation_tolerance_rad']
            if status['final_reference_reached'] and status['consumed']==self.index and near and slow and pose_near and status['endpoint_capture_complete']:
                if quiet is None:quiet=now
                if now-quiet>=stable_s:return status
            else:quiet=None
            time.sleep(.02)
        raise TimeoutError('EE endpoint did not settle within the completion timeout')
