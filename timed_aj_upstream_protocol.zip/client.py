"""Loopback-only ARIS interfaces. Long plans use a separate reply socket."""
import json
import queue
import socket
import struct
import threading
import time
import websocket


def message(body, seq=0):
    return struct.pack('<IIQqqq',len(body),seq,0,0,0,0)+body


def decode(raw):
    if not isinstance(raw,bytes) or len(raw)<40:
        raise ValueError('expected ARIS binary message')
    size=struct.unpack_from('<I',raw)[0]
    if size!=len(raw)-40:raise ValueError('ARIS message length mismatch')
    return json.loads(raw[40:].rstrip(b'\0').decode())


class Client:
    def __init__(self,port=5867):
        self.ws=websocket.create_connection(f'ws://127.0.0.1:{port}',timeout=5,http_proxy_host=None)
        self.seq=0
        self.commands=[]
        self.plan_ws=None
        self.plan_thread=None
        self.plan_pending=queue.Queue()

    def command(self,text,check=True):
        self.seq+=1
        started=time.monotonic_ns()
        self.ws.send_binary(message(text.encode()+b'\0',self.seq))
        reply=decode(self.ws.recv())
        self.commands.append(dict(command=text,start_ns=started,end_ns=time.monotonic_ns(),reply=reply))
        if check and reply.get('ret_code')!=0:raise RuntimeError(f'{text}: {reply}')
        return reply

    def start_plan(self,text):
        # Follower command responds only on completion. Keeping its replies on
        # 5888 prevents its late result from being mistaken for a GET/stop ACK.
        if self.plan_ws is None:
            self.plan_ws=websocket.create_connection('ws://127.0.0.1:5888',timeout=5,http_proxy_host=None)
            self.plan_ws.settimeout(None)
            self.plan_thread=threading.Thread(target=self._read_plans,daemon=True)
            self.plan_thread.start()
        record=dict(command=text,start_ns=time.monotonic_ns(),asynchronous_plan=True)
        self.commands.append(record)
        self.plan_pending.put(record)
        self.plan_ws.send_binary(message(text.encode()+b'\0',1))

    def _read_plans(self):
        try:
            while True:
                raw=self.plan_ws.recv()
                if not raw:break
                record=self.plan_pending.get(timeout=1)
                record.update(end_ns=time.monotonic_ns(),reply=decode(raw))
        except Exception:
            return

    def state(self):
        data=self.command('get')['ret_context']
        return json.loads(data) if isinstance(data,str) else data

    def close(self):
        if self.plan_ws:self.plan_ws.close()
        self.ws.close()
        if self.plan_thread:self.plan_thread.join(timeout=1)


def packet(seq,pos_deg,filtered=False):
    if len(pos_deg)!=12:raise ValueError('UDP requires exactly 12 joints; grippers excluded')
    body=json.dumps({'id':seq,'motor_pos':list(pos_deg),'filter':bool(filtered)},allow_nan=False,
                    separators=(',',':')).encode()+b'\0'
    return message(body)  # vendor UDP header fields other than length are zero
